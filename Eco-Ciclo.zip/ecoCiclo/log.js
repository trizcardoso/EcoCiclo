import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  TextInput,
  SafeAreaView,
  StatusBar,
  Image
} from 'react-native';
import { MaterialIcons, FontAwesome5, Ionicons } from '@expo/vector-icons';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('login'); // 'login' or 'home'
  const [formData, setFormData] = useState({
    nome: '',
    sobrenome: '',
    email: '',
    senha: '',
    regiao: '',
    tipoReciclagem: ''
  });

  const pontosColeta = [
    {
      id: 1,
      nome: "Ecoponto Centro",
      endereco: "Rua Sete de Setembro, 1500 - Centro",
      distancia: "1.2 km"
    },
    {
      id: 2,
      nome: "Ecoponto Vila Prado",
      endereco: "Av. São Carlos, 2350 - Vila Prado",
      distancia: "2.5 km"
    },
    {
      id: 3,
      nome: "Cooperativa Recicla",
      endereco: "Rua Major Manoel, 580 - Vila Nery",
      distancia: "3.1 km"
    }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCreateAccount = () => {
    // Lógica de criação de conta
    setCurrentScreen('home');
  };

  if (currentScreen === 'login') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.appTitle}>EcoCiclo</Text>
          </View>

          {/* Form Section */}
          <View style={styles.formSection}>
            <Text style={styles.sectionTitle}>Criar uma conta</Text>
            <Text style={styles.loginLink}>
              Já possui uma conta? <Text style={styles.loginLinkBold}>Fazer login</Text>
            </Text>

            {/* Name Fields */}
            <View style={styles.row}>
              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.inputLabel}>Nome</Text>
                <TextInput
                  style={styles.input}
                  value={formData.nome}
                  onChangeText={(text) => handleInputChange('nome', text)}
                  placeholder="Digite seu nome"
                />
              </View>
              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.inputLabel}>Sobrenome</Text>
                <TextInput
                  style={styles.input}
                  value={formData.sobrenome}
                  onChangeText={(text) => handleInputChange('sobrenome', text)}
                  placeholder="Digite seu sobrenome"
                />
              </View>
            </View>

            {/* Email */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.input}
                value={formData.email}
                onChangeText={(text) => handleInputChange('email', text)}
                placeholder="seu@email.com"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            {/* Password */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Criar senha</Text>
              <TextInput
                style={styles.input}
                value={formData.senha}
                onChangeText={(text) => handleInputChange('senha', text)}
                placeholder="••••••••"
                secureTextEntry
              />
            </View>

            {/* Region */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Região</Text>
              <TextInput
                style={styles.input}
                value={formData.regiao}
                onChangeText={(text) => handleInputChange('regiao', text)}
                placeholder="Sua região"
              />
            </View>

            {/* Recycling Type */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Tipo de reciclagem</Text>
              <TextInput
                style={styles.input}
                value={formData.tipoReciclagem}
                onChangeText={(text) => handleInputChange('tipoReciclagem', text)}
                placeholder="Seu tipo de reciclagem"
              />
            </View>

            {/* Divider */}
            <View style={styles.divider} />

            {/* Create Account Button */}
            <TouchableOpacity style={styles.createAccountButton} onPress={handleCreateAccount}>
              <Text style={styles.createAccountButtonText}>CRIAR UMA CONTA</Text>
            </TouchableOpacity>

            {/* Social Login */}
            <View style={styles.socialSection}>
              <Text style={styles.socialText}>ou colaborar com</Text>
              <View style={styles.socialButtons}>
                <TouchableOpacity style={styles.socialButton}>
                  <Text style={styles.socialButtonText}>Google</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.socialButton}>
                  <Text style={styles.socialButtonText}>Apple</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Home Screen
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        
        {/* Header */}
        <View style={styles.homeHeader}>
          <Text style={styles.homeTitle}>Home</Text>
        </View>

        {/* Recycling Section */}
        <View style={styles.homeSection}>
          <Text style={styles.homeSectionTitle}>Reciclagem Residencial</Text>
          
          {/* Material Identification Card */}
          <View style={styles.identificationCard}>
            <View style={styles.cardHeader}>
              <MaterialIcons name="photo-camera" size={24} color="#2E7D32" />
              <Text style={styles.cardTitle}>Identificação de material</Text>
            </View>
            <Text style={styles.cardDescription}>
              Tire uma foto de seu material para detectar seu tipo de reciclagem
            </Text>
            <TouchableOpacity style={styles.cameraButton}>
              <MaterialIcons name="camera-alt" size={20} color="white" />
              <Text style={styles.cameraButtonText}>Tirar Foto</Text>
            </TouchableOpacity>
          </View>

          {/* Divider */}
          <View style={styles.homeDivider} />

          {/* Collection Points */}
          <View style={styles.collectionSection}>
            <Text style={styles.collectionTitle}>Pontos de coleta em sua região</Text>
            
            {pontosColeta.map((ponto) => (
              <View key={ponto.id} style={styles.collectionPoint}>
                <View style={styles.pointInfo}>
                  <Text style={styles.pointName}>{ponto.nome}</Text>
                  <Text style={styles.pointAddress}>{ponto.endereco}</Text>
                  <Text style={styles.pointDistance}>{ponto.distancia}</Text>
                </View>
                <TouchableOpacity style={styles.directionsButton}>
                  <MaterialIcons name="directions" size={20} color="#2E7D32" />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  // Login Screen Styles
  header: {
    paddingHorizontal: 24,
    paddingTop: 40,
    paddingBottom: 20,
  },
  appTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1A1A1A',
    textAlign: 'center',
  },
  formSection: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  loginLink: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 32,
  },
  loginLinkBold: {
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  inputContainer: {
    marginBottom: 20,
  },
  halfInput: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    backgroundColor: '#FAFAFA',
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 32,
  },
  createAccountButton: {
    backgroundColor: '#2E7D32',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 32,
  },
  createAccountButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  socialSection: {
    alignItems: 'center',
  },
  socialText: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 16,
  },
  socialButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  socialButton: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
    minWidth: 120,
  },
  socialButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A',
    textAlign: 'center',
  },
  // Home Screen Styles
  homeHeader: {
    paddingHorizontal: 24,
    paddingTop: 40,
    paddingBottom: 20,
  },
  homeTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  homeSection: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  homeSectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 24,
  },
  identificationCard: {
    backgroundColor: '#F8F9FA',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  cardDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 20,
    lineHeight: 20,
  },
  cameraButton: {
    backgroundColor: '#2E7D32',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    alignSelf: 'flex-start',
  },
  cameraButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  homeDivider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 32,
  },
  collectionSection: {
    marginTop: 10,
  },
  collectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 16,
  },
  collectionPoint: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pointInfo: {
    flex: 1,
  },
  pointName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  pointAddress: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  pointDistance: {
    fontSize: 12,
    color: '#2E7D32',
    fontWeight: '500',
  },
  directionsButton: {
    padding: 8,
    backgroundColor: '#E8F5E8',
    borderRadius: 8,
  },
});