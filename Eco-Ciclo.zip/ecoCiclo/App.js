import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking, Alert, Modal, Image } from 'react-native';
import { MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function App() {
  const [facing, setFacing] = useState('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [cameraVisible, setCameraVisible] = useState(false);
  const [fotoTirada, setFotoTirada] = useState(null);
  const [materialDetectado, setMaterialDetectado] = useState(null);
  const [resultadoVisible, setResultadoVisible] = useState(false);
  const cameraRef = useRef(null);

  const pontosColeta = [
    {
      id: 1,
      nome: "Ecoponto Centro",
      endereco: "Rua Sete de Setembro, 1500 - Centro",
      horario: "Seg a Sex: 8h-17h | Sáb: 8h-12h",
      materiais: ["Papel", "Plástico", "Vidro", "Metal"],
      telefone: "(16) 3307-7400"
    },
    {
      id: 2,
      nome: "Ecoponto Vila Prado",
      endereco: "Av. São Carlos, 2350 - Vila Prado",
      horario: "Seg a Sex: 8h-17h | Sáb: 8h-12h",
      materiais: ["Eletrônicos", "Pilhas", "Lâmpadas", "Óleo"],
      telefone: "(16) 3307-7400"
    },
    {
      id: 3,
      nome: "Ecoponto Jardim Zavaglia",
      endereco: "Rua João Zavaglia, 850 - Jardim Zavaglia",
      horario: "Seg a Sex: 8h-17h",
      materiais: ["Papel", "Plástico", "Vidro", "Metal"],
      telefone: "(16) 3307-7400"
    },
    {
      id: 4,
      nome: "Cooperativa de Reciclagem",
      endereco: "Rua Major Manoel Antônio, 580 - Vila Nery",
      horario: "Seg a Sex: 7h-16h | Sáb: 7h-11h",
      materiais: ["Todos os materiais recicláveis"],
      telefone: "(16) 3413-1414"
    },
    {
      id: 5,
      nome: "Supermercado Verde - Coleta de Óleo",
      endereco: "Av. Dr. Carlos Botelho, 2175 - Centro",
      horario: "Todos os dias: 8h-22h",
      materiais: ["Óleo de cozinha"],
      telefone: "(16) 3371-2000"
    },
    {
      id: 6,
      nome: "Shopping São Carlos - Ponto de Coleta",
      endereco: "Av. São Carlos, 2385 - Vila Prado",
      horario: "Seg a Dom: 10h-22h",
      materiais: ["Eletrônicos", "Pilhas", "Baterias"],
      telefone: "(16) 3368-9000"
    }
  ];

  const detectarMaterial = (fotoUri) => {
    const materiais = ['Plástico', 'Papel', 'Vidro', 'Metal', 'Orgânico', 'Eletrônico'];
    const materialAleatorio = materiais[Math.floor(Math.random() * materiais.length)];
    
    setTimeout(() => {
      setMaterialDetectado(materialAleatorio);
      setResultadoVisible(true);
    }, 2000);
  };

  const tirarFoto = async () => {
    if (cameraRef.current) {
      try {
        const foto = await cameraRef.current.takePictureAsync({
          quality: 0.8,
          base64: true,
        });
        setFotoTirada(foto.uri);
        setCameraVisible(false);
        detectarMaterial(foto.uri);
      } catch (error) {
        Alert.alert('Erro', 'Não foi possível tirar a foto');
      }
    }
  };

  const abrirCamera = async () => {
    if (!permission) {
      await requestPermission();
    }

    if (permission && !permission.granted) {
      Alert.alert(
        'Permissão necessária',
        'Precisamos da permissão da câmera para identificar os materiais.',
        [
          {
            text: 'Cancelar',
            style: 'cancel',
          },
          {
            text: 'Permitir',
            onPress: requestPermission,
          },
        ]
      );
      return;
    }

    setCameraVisible(true);
    setMaterialDetectado(null);
    setFotoTirada(null);
  };

  const fecharCamera = () => {
    setCameraVisible(false);
  };

  const fecharResultado = () => {
    setResultadoVisible(false);
    setFotoTirada(null);
    setMaterialDetectado(null);
  };

  const getMaterialInfo = (material) => {
    const info = {
      'Plástico': {
        cor: '#FF6B35',
        descricao: 'Garrafas, embalagens, potes',
        icone: '🔄',
        pontos: pontosColeta.filter(p => p.materiais.some(m => m === 'Plástico' || m === 'Todos os materiais recicláveis'))
      },
      'Papel': {
        cor: '#2196F3',
        descricao: 'Jornais, revistas, caixas',
        icone: '📄',
        pontos: pontosColeta.filter(p => p.materiais.some(m => m === 'Papel' || m === 'Todos os materiais recicláveis'))
      },
      'Vidro': {
        cor: '#4CAF50',
        descricao: 'Garrafas, potes, frascos',
        icone: '🥛',
        pontos: pontosColeta.filter(p => p.materiais.some(m => m === 'Vidro' || m === 'Todos os materiais recicláveis'))
      },
      'Metal': {
        cor: '#FFC107',
        descricao: 'Latas, arames, objetos metálicos',
        icone: '🔩',
        pontos: pontosColeta.filter(p => p.materiais.some(m => m === 'Metal' || m === 'Todos os materiais recicláveis'))
      },
      'Eletrônico': {
        cor: '#9C27B0',
        descricao: 'Pilhas, baterias, eletroeletrônicos',
        icone: '🔌',
        pontos: pontosColeta.filter(p => p.materiais.some(m => m === 'Eletrônicos' || m === 'Pilhas' || m === 'Baterias'))
      },
      'Orgânico': {
        cor: '#795548',
        descricao: 'Restos de comida, cascas de frutas',
        icone: '🍎',
        pontos: [] 
      }
    };
    return info[material] || { cor: '#666', descricao: 'Material não identificado', icone: '❓', pontos: [] };
  };

  const handleLigar = (telefone) => {
    Linking.openURL(`tel:${telefone}`);
  };

  const handleMaps = (endereco) => {
    const url = `https://maps.google.com/?q=${encodeURIComponent(endereco)}`;
    Linking.openURL(url);
  };

  if (!permission) {
    return (
      <View style={styles.container}>
        <Text>Carregando...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* Cabeçalho */}
      <View style={styles.header}>
        <FontAwesome5 name="recycle" size={28} color="white" />
        <Text style={styles.headerTitle}>EcoCiclo</Text>
        <MaterialIcons name="location-on" size={24} color="white" />
      </View>

      {/* Seção de Reciclagem Residencial */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Reciclagem Residencial</Text>
        
        {/* Card de Identificação de Material */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialIcons name="photo-camera" size={24} color="#2E7D32" />
            <Text style={styles.cardTitle}>Identificação de material</Text>
          </View>
          <Text style={styles.cardDescription}>
            Tire uma foto de seu material para detectar seu tipo de reciclagem
          </Text>
          <TouchableOpacity style={styles.cameraButton} onPress={abrirCamera}>
            <MaterialIcons name="camera-alt" size={20} color="white" />
            <Text style={styles.cameraButtonText}>Tirar Foto do Material</Text>
          </TouchableOpacity>
        </View>

        {/* Linha divisória */}
        <View style={styles.divider} />

        {/* Seção de Pontos de Coleta */}
        <View style={styles.collectionSection}>
          <View style={styles.sectionHeader}>
            <MaterialIcons name="location-on" size={24} color="#FF6B35" />
            <Text style={styles.collectionTitle}>Pontos de Coleta - São Carlos</Text>
          </View>
          
          {pontosColeta.map((ponto) => (
            <View key={ponto.id} style={styles.pontoCard}>
              <View style={styles.pontoHeader}>
                <Text style={styles.pontoNome}>{ponto.nome}</Text>
                <View style={styles.statusIndicator}>
                  <View style={styles.statusDot} />
                  <Text style={styles.statusText}>Aberto</Text>
                </View>
              </View>
              
              <View style={styles.pontoInfo}>
                <MaterialIcons name="place" size={16} color="#666" />
                <Text style={styles.pontoEndereco}>{ponto.endereco}</Text>
              </View>
              
              <View style={styles.pontoInfo}>
                <MaterialIcons name="access-time" size={16} color="#666" />
                <Text style={styles.pontoHorario}>{ponto.horario}</Text>
              </View>
              
              <View style={styles.materiaisContainer}>
                <Text style={styles.materiaisTitle}>Materiais aceitos:</Text>
                <View style={styles.materiaisList}>
                  {ponto.materiais.map((material, index) => (
                    <View key={index} style={styles.materialTag}>
                      <Text style={styles.materialText}>{material}</Text>
                    </View>
                  ))}
                </View>
              </View>
              
              <View style={styles.actions}>
                <TouchableOpacity 
                  style={styles.actionButton}
                  onPress={() => handleLigar(ponto.telefone)}
                >
                  <MaterialIcons name="phone" size={16} color="white" />
                  <Text style={styles.actionText}>Ligar</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[styles.actionButton, styles.mapsButton]}
                  onPress={() => handleMaps(ponto.endereco)}
                >
                  <MaterialIcons name="directions" size={16} color="white" />
                  <Text style={styles.actionText}>Como chegar</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Modal da Câmera */}
      <Modal
        visible={cameraVisible}
        animationType="slide"
        statusBarTranslucent={true}
      >
        <View style={styles.cameraContainer}>
          <CameraView
            ref={cameraRef}
            style={styles.camera}
            facing={facing}
          >
            <View style={styles.cameraControls}>
              <TouchableOpacity style={styles.cameraButtonClose} onPress={fecharCamera}>
                <MaterialIcons name="close" size={30} color="white" />
              </TouchableOpacity>
              
              <View style={styles.cameraButtonContainer}>
                <TouchableOpacity style={styles.cameraCaptureButton} onPress={tirarFoto}>
                  <View style={styles.cameraCaptureButtonInner} />
                </TouchableOpacity>
              </View>

              <TouchableOpacity 
                style={styles.cameraFlipButton}
                onPress={() => setFacing(current => (current === 'back' ? 'front' : 'back'))}
              >
                <MaterialIcons name="flip-camera-ios" size={30} color="white" />
              </TouchableOpacity>
            </View>
          </CameraView>
        </View>
      </Modal>

      {/* Modal de Resultado */}
      <Modal
        visible={resultadoVisible}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            {materialDetectado && (
              <>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Material Identificado!</Text>
                  <TouchableOpacity onPress={fecharResultado}>
                    <MaterialIcons name="close" size={24} color="#666" />
                  </TouchableOpacity>
                </View>

                <View style={[styles.materialResult, { backgroundColor: getMaterialInfo(materialDetectado).cor }]}>
                  <Text style={styles.materialIcon}>{getMaterialInfo(materialDetectado).icone}</Text>
                  <Text style={styles.materialName}>{materialDetectado}</Text>
                </View>

                <Text style={styles.materialDescription}>
                  {getMaterialInfo(materialDetectado).descricao}
                </Text>

                {fotoTirada && (
                  <Image source={{ uri: fotoTirada }} style={styles.fotoPreview} />
                )}

                {getMaterialInfo(materialDetectado).pontos.length > 0 ? (
                  <View style={styles.pontosSugeridos}>
                    <Text style={styles.pontosTitle}>Pontos de coleta sugeridos:</Text>
                    {getMaterialInfo(materialDetectado).pontos.slice(0, 3).map(ponto => (
                      <TouchableOpacity 
                        key={ponto.id} 
                        style={styles.pontoSugerido}
                        onPress={() => handleMaps(ponto.endereco)}
                      >
                        <Text style={styles.pontoSugeridoNome}>{ponto.nome}</Text>
                        <Text style={styles.pontoSugeridoEndereco}>{ponto.endereco}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                ) : materialDetectado === 'Orgânico' ? (
                  <View style={styles.compostagemInfo}>
                    <Text style={styles.compostagemTitle}>💡 Dica de Compostagem</Text>
                    <Text style={styles.compostagemText}>
                      Este material é orgânico. Considere fazer compostagem doméstica para transformar em adubo!
                    </Text>
                  </View>
                ) : null}

                <TouchableOpacity style={styles.novaFotoButton} onPress={abrirCamera}>
                  <Text style={styles.novaFotoText}>Tirar Nova Foto</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    backgroundColor: '#2E7D32',
    paddingVertical: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#2E7D32',
    textAlign: 'center',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    gap: 8,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
    marginBottom: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  cardDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
    lineHeight: 20,
  },
  cameraButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  cameraButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  divider: {
    height: 2,
    backgroundColor: '#E0E0E0',
    marginVertical: 25,
    borderRadius: 1,
  },
  collectionSection: {
    marginTop: 10,
  },
  collectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF6B35',
  },
  pontoCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  pontoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pontoNome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4CAF50',
  },
  statusText: {
    fontSize: 12,
    color: '#4CAF50',
    fontWeight: '500',
  },
  pontoInfo: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
    gap: 8,
  },
  pontoEndereco: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 20,
  },
  pontoHorario: {
    fontSize: 14,
    color: '#666',
    flex: 1,
  },
  materiaisContainer: {
    marginTop: 12,
    marginBottom: 16,
  },
  materiaisTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  materiaisList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  materialTag: {
    backgroundColor: '#E8F5E8',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#4CAF50',
  },
  materialText: {
    fontSize: 12,
    color: '#2E7D32',
    fontWeight: '500',
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    backgroundColor: '#2E7D32',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    justifyContent: 'center',
  },
  mapsButton: {
    backgroundColor: '#FF6B35',
  },
  actionText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  // Estilos da Câmera
  cameraContainer: {
    flex: 1,
    backgroundColor: 'black',
  },
  camera: {
    flex: 1,
  },
  cameraControls: {
    flex: 1,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    padding: 30,
  },
  cameraButtonClose: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 1,
  },
  cameraButtonContainer: {
    flex: 1,
    alignItems: 'center',
  },
  cameraCaptureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cameraCaptureButtonInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'white',
  },
  cameraFlipButton: {
    position: 'absolute',
    top: 50,
    right: 20,
  },
  // Estilos do Modal de Resultado
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  materialResult: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    borderRadius: 16,
    marginBottom: 16,
    gap: 12,
  },
  materialIcon: {
    fontSize: 32,
  },
  materialName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  materialDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },
  fotoPreview: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  pontosSugeridos: {
    marginBottom: 16,
  },
  pontosTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  pontoSugerido: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  pontoSugeridoNome: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  pontoSugeridoEndereco: {
    fontSize: 12,
    color: '#666',
  },
  compostagemInfo: {
    backgroundColor: '#FFF3E0',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800',
  },
  compostagemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E65100',
    marginBottom: 8,
  },
  compostagemText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  novaFotoButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  novaFotoText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});